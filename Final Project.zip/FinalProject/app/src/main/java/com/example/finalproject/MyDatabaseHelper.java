package com.example.finalproject;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.Nullable;


public class MyDatabaseHelper extends SQLiteOpenHelper{

    private Context context;
    private static final String TABLE_NAME = "My_Database";
    private static final String Database_Name = "InventoryApplication.db";
    private static final int Database_Version = 1;

    private static final String Table_Name = "Current Inventory";
    private static final String Column_ID = "_id";
    private static final String Column_Quantity = "Quantity";
    private static final String Column_Name = "Name";
    private static final String Column_SKU  = "SKU";


    MyDatabaseHelper(@Nullable Context context) {
        super(context, Database_Name, null, Database_Version);
        this.context = context;

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + Table_Name +
                " (" + Column_ID + " Integer Primary Key Autoincrement, " +
                Column_Name + " TEXT, " +
                Column_Quantity + "TEXT, " +
                Column_SKU + "INTEGER);";
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    void addItem(String Name, String Quantity, int SKU){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(Column_Name, Name);
        cv.put(Column_Quantity, Quantity);
        cv.put(Column_SKU, SKU);
        long result = db.insert(Table_Name,null, cv);
        if(result == 0){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Added Successfully!", Toast.LENGTH_SHORT).show();
        }
    }
    Cursor readAllData(){
        String query = "SELECT * FROM " + Table_Name;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }
    void updateData(String row_id, String Product_Name, String Quantity, String SKU){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Column_Name, Product_Name);
        cv.put(Column_Quantity, Quantity);
        cv.put(Column_SKU, SKU);

        long result = db.update(Table_Name, cv, "_id?", new String[]{row_id});
        if(result == -1){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Updated Successfully!", Toast.LENGTH_SHORT).show();
        }

    }
    void deleteOneRow(String row_id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(Table_Name, "_id?", new String[]{row_id});
        if(result == -1){
            Toast.makeText(context, "Failed to Delete.", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Successfully Deleted.", Toast.LENGTH_SHORT).show();
        }
    }
    void deleteAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + Table_Name);
    }
}