package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    EditText productname_input, quantity_input, SKU_input;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        productname_input = findViewById(R.id.productname_input);
        quantity_input = findViewById(R.id.quantity_input);
        SKU_input = findViewById(R.id.SKU_input);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);
                myDB.addItem(productname_input.getText().toString().trim(),
                        quantity_input.getText().toString().trim(),
                        Integer.valueOf(SKU_input.getText().toString().trim()));
            }
        });
    }
}